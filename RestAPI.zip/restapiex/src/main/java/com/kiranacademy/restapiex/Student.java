package com.kiranacademy.restapiex;

public class Student {
	int rno;
	int rmarks;
	Student(){}
	
	public int getRno() {
		return rno;
	}
	public void setRno(int rno) {
		this.rno = rno;
	}
	public int getRmarks() {
		return rmarks;
	}
	public void setRmarks(int rmarks) {
		this.rmarks = rmarks;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	String rname;
	public Student(int rno, int rmarks, String rname) {
		super();
		this.rno = rno;
		this.rmarks = rmarks;
		this.rname = rname;
	}
	@Override
	public String toString() {
		return "Student [rno=" + rno + ", rmarks=" + rmarks + ", rname=" + rname + "]";
	}

}
