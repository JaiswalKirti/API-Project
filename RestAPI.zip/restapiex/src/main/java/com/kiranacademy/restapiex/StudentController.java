package com.kiranacademy.restapiex;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class StudentController {
ArrayList<Student> arraylist = new ArrayList<Student>();

StudentController()
{
	Student student1 = new Student(1,77,"kirti");
	Student student2 = new Student(2,89,"Ritu");
	
   arraylist.add(student1);
   arraylist.add(student2);
   
}



@GetMapping("Students")
 ArrayList<Student> allStudents()
 {
	return arraylist;
 }



@RequestMapping("Student/{rno}")
 public Student getStudent(@PathVariable int rno)
 {
	System.out.println(rno);
	for(Student student: arraylist)
	{
		if(student.rno==rno)
			return student;
	}
	return null;
 }




@PostMapping("Student")
  public ArrayList<Student> addStudent(@RequestBody Student student)
  {
	arraylist.add(student);
	return arraylist;
  }
 @DeleteMapping("Student/{rno}")
  public String deleteStudent (@PathVariable int rno)
  {
	 for(Student student : arraylist)
	 {
		 if(student.rno==rno)
			 arraylist.remove(student);
	 }
	 return "record deleted";
  }
 
 
 
 
 @SuppressWarnings("rawtypes")
@PutMapping("Student{rno}")
 public ArrayList updateStudent(@RequestBody Student clientStudent)
 {
	 for(Student student1 :arraylist)
	 {
		 if(student1.rno==clientStudent.rno)
		 {
			 student1.setRmarks(clientStudent.getRmarks());
		 }
	 }
	 return arraylist;
		 }
	 
	}


